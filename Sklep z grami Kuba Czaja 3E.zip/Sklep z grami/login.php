<?php
session_start();

$host = 'localhost';
$db = 'logowanie';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Nieprawidłowy e-mail.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();

        $_SESSION['user_email'] = $email;
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Logowanie</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <h2>Logowanie</h2>
  <?php if ($error): ?>
    <p style="color:red;"><?php echo $error; ?></p>
  <?php endif; ?>
  <form method="POST" action="">
    <label for="email">E-mail:</label><br>
    <input type="text" id="email" name="email" required><br><br>

    <label for="password">Hasło:</label><br>
    <input type="password" id="password" name="password" required><br><br>

    <input type="submit" value="Zaloguj">
  </form>
</body>
</html>