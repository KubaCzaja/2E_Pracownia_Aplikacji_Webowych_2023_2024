<?php
?>

<header>
  <h1 class="header-title">
    <span>Sklep z grami</span>
  </h1>
  <div class="search-bar">
    <input
      type="text"
      class="search-bar-input"
      placeholder="Wyszukaj..."
    />
    <div class="search-bar-icon">
      <img src="./images/lupa.svg" alt="search-icon" />
    </div>
  </div>
  <div class="header-basket">
    <img src="./images/shopping_cart.svg" alt="shopping-cart-icon" />
    <p class="basket-amount">Koszyk</p>
    <button class="basket-clear-btn">x</button>
  </div>
  <div class="login-button">
    <?php if (isset($_SESSION['user_email'])): ?>
      <span style="padding-left: 1rem;"><?php echo htmlspecialchars($_SESSION['user_email']); ?></span>
      <a href="logout.php"><button>Wyloguj się</button></a>
    <?php else: ?>
      <a href="login.php"><button>Zaloguj się</button></a>
    <?php endif; ?>
  </div>
</header>