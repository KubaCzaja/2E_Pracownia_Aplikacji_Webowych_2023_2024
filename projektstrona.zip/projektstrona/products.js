const products = [
    {
      id: 0,
      name: "Metal Gear Solid Δ: Snake Eater",
      category: "PS5",
      description: `Remake METAL GEAR SOLID 3: SNAKE EATER z 2004 roku – opowiadający tę samą, zapierającą dech historię i przedstawiającą znany, pasjonujący świat w nowej oprawie graficznej oraz z dźwiękiem 3D, pogłębiającymi atmosferę dżungli. Sprawdź się w doszlifowanej do granic survivalowej skradance.`,
      price: 350,
      image: "./images/mgs3.webp"
    },
    {
      id: 1,
      name: "Kingdom Come: Deliverance II",
      description: `Porywające, napędzane fabułą RPG akcji z bogatym otwartym światem, osadzone w średniowiecznej Europie XV. wieku. Wyrusz w podróż o epickim rozmachu i − oczami młodego Henryka − przeżyj niedoścignioną średniowieczną przygodę.`,
      category: "XBOX X/S",
      price: 270,
      image: "./images/kcd2.webp"
    },
    {
      id: 2,
      name: "Bloodborne",
      description: `Samotny podróżnik. Przeklęte miasto. Zabójcza tajemnica, pochłaniająca wszystko, z czym się zetknie. Zmierz się ze swoimi obawami i wejdź do popadającego w ruinę miasta Yharnam, przeklętego miejsca, dotkniętego straszliwą epidemią. Zbadaj jego mroczne zakamarki, walcz o życie, używając broni palnej i białej, oraz odkryj tajemnice, które zmrożą ci krew w żyłach... ale być może ocalą ci skórę...`,
      category: "PS4",
      price: 80,
      image: "./images/bb.webp",
    },
  ];